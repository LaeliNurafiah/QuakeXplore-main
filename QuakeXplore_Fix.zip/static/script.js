// // Fungsi untuk membuka popup chatbot
// function openChatbot() {
//   document.getElementById("chatbot-popup").style.display = "block";
// }

// // Fungsi untuk menutup popup chatbot
// function closeChatbot() {
//   document.getElementById("chatbot-popup").style.display = "none";
// }

// function showArticleDetails(articleId) {
//     // Setiap artikel memiliki ID unik untuk detailnya
//     if (articleId === 1) {
//       window.location.href = "https://www.bmkg.go.id/berita/?p=ulasan-guncangan-tanah-akibat-gempabumi-di-sumedang-31-desember-2023&lang=ID&s=detil";
//     } else if (articleId === 2) {
//       window.location.href = "link_artikel_2";
//     } else if (articleId === 3) {
//       window.location.href = "link_artikel_3";
//     } else if (articleId === 4) {
//       window.location.href = "link_artikel_4";
//     }
//     // Tambahkan case untuk artikel lain jika diperlukan
//   }
//   // script.js

// // function openChatbot() {
// //   // Menggunakan fetch API untuk memuat konten chatbot dari chatbot.html
// //   fetch('chatbot.html')
// //       .then(response => response.text())
// //       .then(html => {
// //           // Memasukkan konten chatbot ke dalam popup
// //           document.getElementById('chatbot-popup').innerHTML = html;
// //           document.getElementById('chatbot-popup').style.display = 'block';
// //       });
// // }

// // function closeChatbot() {
// //   document.getElementById('chatbot-popup').style.display = 'none';
// // }

// // document.addEventListener("DOMContentLoaded", function() {
// //   var klasifikasiLink = document.querySelector('[data-nav-link="Klasifikasi"]');
// //   var dropdownMenu = document.querySelector('.dropdown-menu');

// //   klasifikasiLink.addEventListener("click", function(event) {
// //     event.preventDefault();
// //     dropdownMenu.classList.toggle("active");
// //   });
// // });


